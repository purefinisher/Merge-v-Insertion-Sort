/**
 * @author raghavthapa
 * 9/24/18
 * Programming Assignment 2
 * Measuring Run Times
 */


import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Driver {

	public static void main(String[] args) {

		double sum = 0; double mergeSum = 0; double avrgInsertion = 0; double avrgMerge = 0;

		int iter;

		ArrayList <String> uA = new ArrayList<>();
		ArrayList <String> sortedInsertion = new ArrayList<>();
		ArrayList <String> sortedMerge = new ArrayList<>();

		Scanner dataIn = null;
		try {

			dataIn = new Scanner(new File(args[0]));
			while (dataIn.hasNext()) {
				uA.add(dataIn.next());

			}

		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
			System.exit(0); 
		}

		for (int n = 2; n <= 8192; n = n*2) {
			iter = Math.max(4, 8192/n);
			CpuTimer timer1 = new CpuTimer();
			for (int i = 0; i < iter; i++) {
				sortedInsertion = InsertionSort(uA, n);
			}

			sum = timer1.getElapsedCpuTime();
			avrgInsertion = sum / iter;

			if (AlphaSorted(uA) || !AlphaSorted(sortedInsertion) || (checkHash(uA, n) != checkHash(sortedInsertion, n))) {
				System.out.println("Error");
				System.exit(0);
			}

			CpuTimer timer2 = new CpuTimer();
			for (int i = 0; i < iter; i++) {
				sortedMerge = setup(uA, n);
			}

			mergeSum = timer2.getElapsedCpuTime();
			avrgMerge = mergeSum / iter;

			if (AlphaSorted(uA) || !AlphaSorted(sortedMerge) || (checkHash(uA, n) != checkHash(sortedMerge, n))) {
				System.out.println("Error");
				System.exit(0);
			}
			System.out.println("Avg. times for n = " + n + ": Insertion Sort " + avrgInsertion + " sec., Merge Sort " + avrgMerge + " sec.");
		}
	}

	static boolean AlphaSorted (ArrayList<String> list) {
		for (int i = 0; i < list.size() - 1; i++) {
			if(list.get(i).compareTo(list.get(i+1)) > 0) {
				return false;
			}
		}
		return true;
	}
//DONE
	static int checkHash (ArrayList <String> list, int n) {
		int hash = 0;
		for (int i = 0; i < n; i++) {
			hash ^= list.get(i).hashCode();
		}
		return hash;
	}
//DONE
	static ArrayList<String> InsertionSort(ArrayList<String> a, int n) {

		ArrayList <String> uA = new ArrayList<>();
		for(int i = 0; i < n; i++) {
			uA.add(a.get(i));
		}

		// For 2nd through last items
		for (int j = 1; j < uA.size(); ++j) {
			// Copy value of next item
			String key = uA.get(j);
			// Start looking here for insertion point
			int i = j - 1;
			// Keep looking while more to search and current value is > key
			while (i >= 0 && uA.get(i).compareTo(key) > 0) {
				// Move current value up one
				uA.set(i+1, uA.get(i));
				// Continue looking to the left
				--i;
			}
			// Put key in sequence
			a.set(i+1, key);
		}
		return uA;
	}

	// Recursive method
	private static void mergeSort (ArrayList <String> list, int start, int end) {
		if(start < end) {
			int middle = start + (end-start)/2;
			mergeSort(list, start, middle);
			mergeSort(list, middle + 1, end);
			merge(list, start, middle, end);
		}
	}

	// DONE
	public static ArrayList <String> setup (ArrayList<String> input, int n){
		ArrayList <String> list = new ArrayList<>(input.subList(0, n));
		mergeSort(list, 0, list.size() - 1);
		return list;
	}

	// DONE
	private static void merge (ArrayList <String> list, int start, int middle, int end) {

		int n1 = middle - start + 1;
		int n2 = end - middle;

		String [] left = new String [n1];
		String [] right = new String [n2];

		int i, j;
		for (i = 0; i < n1; i++) {
			left[i] = list.get(start + i);
		}
		for (j = 0; j < n2; j++) {
			right[j] = list.get(middle + 1 + j);
		}
		i = j = 0;

		int k = start;

		while (i < n1 && j < n2) {
			if(left[i].compareTo(right[j]) <= 0) {
				list.set(k,left[i]);
				i++;
			} else {
				list.set(k, right[j]);
				j++;
			}
			k++;
		} while (i < n1){
			list.set(k,left[i]);
			i++;
			k++;
		} while (j < n2) {
			list.set(k,right[j]);
			j++;
			k++;
		}
	}
}
